# Objet / Malédiction “Poison”

Type : Malédiction transportable (peut être portée par n’importe quel héros)

Effets

Lorsqu’il est utilisé par le porteur :

Le porteur reçoit 4 points de Poison (Poison).

L’objet est détruit (Bomb Destroyed).

Lorsqu’un autre objet dans la même ligne est utilisé :

Le porteur reçoit 1 point de Poison (Poison).