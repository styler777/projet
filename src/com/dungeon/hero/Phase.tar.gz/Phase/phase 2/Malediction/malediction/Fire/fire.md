# FIRE

Type : Malédiction transportable (peut être portée par n’importe quel héros)

**Effets**

Effet automatique chaque tour :

Crée du feu dans une case adjacente ou diagonale aléatoire autour de l’objet.

Quand l’objet est utilisé par le porteur :

Applique 2 points de brûlure (Burn) au porteur.

L’objet est détruit après usage.

Quand un objet derrière celui-ci est utilisé :

Applique 1 point de brûlure (Burn) au porteur.