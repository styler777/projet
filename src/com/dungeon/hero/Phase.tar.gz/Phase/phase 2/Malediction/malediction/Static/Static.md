# Objet / Malédiction “Static”

Type : Malédiction transportable (peut être portée par n’importe quel héros)

Effets

Lorsqu’il est utilisé par le porteur :

Inflige 2 points de dégâts (Attack) au porteur.

L’objet est détruit (Bomb Destroyed).

À la fin du tour du porteur :

Crée une zone de Static (Static) dans la case située juste en dessous de l’objet.