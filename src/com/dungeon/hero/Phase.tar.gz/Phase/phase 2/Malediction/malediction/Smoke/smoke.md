# Objet / Malédiction “Smoke Plume”

Type : Malédiction transportable (peut être portée par n’importe quel héros)

Effets

Lorsqu’il est utilisé par le porteur :

L’objet est détruit (Bomb Destroyed).

À la fin de ton tour :

L’objet est détruit automatiquement (Bomb Destroyed).

Quand l’objet est détruit :

Crée des plumes de fumée (Smoke Plumes) dans toutes les cases de la colonne où se trouvait l’objet.