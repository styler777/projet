# Objet / Malédiction “Maladies”

Type : Malédiction transportable (peut être portée par n’importe quel héros)

Effets

Lorsqu’il est utilisé par le porteur :

Crée des Maladies (Malady) dans 2 cases adjacentes ou diagonales autour de l’objet.

L’objet est détruit (Bomb Destroyed).

Lorsqu’un autre objet dans la même ligne est utilisé :

Le porteur reçoit 1 point de Poison (Poison).