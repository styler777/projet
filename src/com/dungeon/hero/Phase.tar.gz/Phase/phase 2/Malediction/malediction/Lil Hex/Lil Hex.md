# Objet / Malédiction “Perte d’énergie”

Type : Malédiction transportable

Effets

Lorsqu’il est utilisé :

L’objet est détruit (Bomb Destroyed).

Chaque tour :

Réduit de 1 ton gain d’énergie total pour tout le combat en cours.

Autrement dit, tu commences chaque tour avec 1 énergie de moins jusqu’à la fin du combat.