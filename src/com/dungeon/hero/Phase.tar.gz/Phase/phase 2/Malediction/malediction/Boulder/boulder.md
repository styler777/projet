# 🪨 Objet / Malédiction — « Rocher » (Boulder)

Type : Malédiction transportable

## ⚙️ Effets

Lorsqu’il est utilisé :

L’objet est détruit (Bomb Destroyed).

À la fin de ton tour :

Crée un Rocher (Boulder) — un obstacle ou objet lourd qui prend de la place dans ton sac à dos.