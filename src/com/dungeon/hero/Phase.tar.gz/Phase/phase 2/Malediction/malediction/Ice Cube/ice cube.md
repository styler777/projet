# Objet / Malédiction “+1 Énergie / Usages limités”

Type : Malédiction transportable

Effets

Nombre d’utilisations :

Peut être utilisé 2 fois maximum.

Lorsqu’il est utilisé :

Augmente le coût en énergie de +1 pour le reste du tour.

Quand toutes les utilisations sont épuisées :

L’objet est détruit (Bomb Destroyed).
