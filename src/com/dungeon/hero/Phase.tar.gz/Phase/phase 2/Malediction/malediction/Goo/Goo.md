# Objet / Malédiction “Goo”

Type : Malédiction transportable (peut être porté par n’importe quel héros)

Effets

Effet automatique chaque tour :

Crée du Goo (substance collante) dans toutes les cases adjacentes à l’objet.

Quand l’objet est utilisé par le porteur :

L’objet est détruit (Bomb Destroyed).

Quand l’objet est détruit :

Tous les autres hazards (objets dangereux) adjacents sont également détruits.