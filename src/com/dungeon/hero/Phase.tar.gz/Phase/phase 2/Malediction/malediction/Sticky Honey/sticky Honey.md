# Objet / Effet

Type : Malédiction ou effet d’objet transportable

Effets

Lorsqu’il est utilisé :

L’objet est détruit (Bomb Destroyed).

À la fin de ton tour :

Les objets placés derrière lui sont ancrés (Anchored) pour +2 combats.

Cela signifie qu’ils restent immobiles ou protégés pendant ces tours supplémentaires.