# ⚔️ Objet / Malédiction — « Perte d’Énergie continue »

Type : Malédiction transportable (elle occupe une place dans ton sac et agit tant qu’elle est là)

## 🧩 Effets

Lorsqu’il est utilisé :

L’objet est détruit (Bomb Destroyed).

Chaque tour (effet passif) :

Tu perds 1 point d’énergie disponible pour le reste du combat en cours.

Cela veut dire que si tu avais 3 énergies par tour, tu passeras à 2, puis 1, etc., tant que le combat continue.