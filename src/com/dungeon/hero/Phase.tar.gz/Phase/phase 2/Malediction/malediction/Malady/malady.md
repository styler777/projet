# Objet / Malédiction “Poison → Malédiction”

Type : Malédiction transportable

Effets

Lorsqu’il est utilisé par le porteur :

Inflige 2 points de Poison (Poison) au porteur.

L’objet est détruit (Bomb Destroyed).

À la fin du tour du porteur :

L’objet est remplacé par une nouvelle malédiction (Malediction), qui continuera à produire des effets négatifs.