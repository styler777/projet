# Phase 2

## Expérience

- gagner un niveau 3 ou 4 cases dans notre sac à dos

## Equipement

- départ : arme basique (épée en bois) et potion de soin ou petit bouclier

- intéragir (effet spéciaux)

- après combat gagné :
  
  - équipements obtenus aléatoirement 90%

(à définir)

## Effet de combat 100%

## malédiction 100%

(à définir)
