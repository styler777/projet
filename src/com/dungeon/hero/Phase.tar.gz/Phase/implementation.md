### 1️⃣ Héros

Hero (class)

- sac : Sac (record)
- carteDonjon : List<Etage>
- equipements : List<Equipement>
- vieRecord : VieRecord

### VieRecord

VieRecord (record)

- protection : int
- vie : int
- santé : int



## 2️⃣ Ennemi

Ennemi (record)

- attaque : List<Attaque>
- protection : List<Protection>
- vie : int
- experience : int



## 3️⃣ Salle

Salle (interface)

- couloir : Couloir
- ennemis : List<Ennemi>
- marchand : Marchand
- tresor : Tresor

## 4️⃣ Equipement

Equipement (interface)

- Arme : Arme
- Magie : Magic

## Arme



## 5️⃣ Etage

Etage (record)

- map : Map<Position, Salle>
- position : int

## 6️⃣ Effet de combat

EffetCombat (record)

- type : StatusEffect
- valeur : int
- cible : Hero | Ennemi
- durée : int

## 7️⃣ Score

Score (class)

- points : int
- temps : int
- ennemisTues : int

## 8️⃣ Malédiction

Malédiction (record)

- nom : string
- effet : EffetCombat
- type : Transportable | Corporelle
- déclencheur : OnUse | EndOfTurn | OnDestroy

## CréationSalleAleatoire

- tresor = liste d'équipement en brut (aléatoire)

- ennemies = liste enemies (2 à 5)

- marchant = liste d'équipement du plus médiocre au plus performant , on supprime les 5 premiers 

- raccourci = on retirer toutes les salles adjacentes qui sont des couloirs pour en une qui nest pas un raccourci 

## Score

liste<vie> vies

- format parties 

- load list<vie>

- trier les vies

- renvoyer les 3 meilleurs vies



## Graphique

* affichage Héro

* Affichage Salle (création de chaque salle)

* Affichage sac à dos 

* Affichage vie

* Affichage de l'intro du jeu  










