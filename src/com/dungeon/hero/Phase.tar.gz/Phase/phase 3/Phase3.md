# Phase 3

## Score (gérer moi-même) 0%

- nombre de points de vie maximal du héros

- somme des prix de ses équipements

- Hall of Fame (enregistrement des 3 meilleurs parties):
  
  -> trier toutes les parties par score/niveau/expérience
  
  -> afficher les 3 meilleures

## Ennemies 100%

- sorcier-grenouille

- ombre vivante

- reine des abeilles

## Étage(générer aléatoirement)

- ajout grille 

- déplacement salle en salle
