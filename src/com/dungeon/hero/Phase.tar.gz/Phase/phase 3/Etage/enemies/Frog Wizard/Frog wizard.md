# Frog Wizard


**Points de vie :** 60 pts

**Expérience :** 10 xp

**Equipements :**

![Texte alternatif](40px-Status_Regen_All.webp "Titre de l'image")

![Texte alternatif](40px-Status_Poison.webp "Titre de l'image")

![Texte alternatif](40px-Attack.webp "Titre de l'image")