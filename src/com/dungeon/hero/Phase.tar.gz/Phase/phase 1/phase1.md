# PHASE 1

## Hero

—  40 pts de vie

## Equipement

— une arme de mêlée ; 100%

— une arme à distance (fléchette, ou bien un arc et des flèches) ;100%

— une armure ;100%

— un bouclier ;100%

— un objet magique requérant de la mana pour fonctionner ;100%

— des pierres de mana ;100%

— de l’or, bien sûr 100%

## Sac à dos (static pas de changement de forme)

— 15 cases

— 3 lignes , 5 colonnes

## Attaque

— Attaque l'ennemi 0%

— niveau de protection 0%

## Etage

On a 3 étages 

— 3 couloirs 0%

— 3 salles ennemis 0%

— salle avec un marchand 50%

— une salle avec un guérisseur, 50%

— deux salles contenant un trésor, 50%

## Ennemies

### Type d'ennemie

— petits rats-loups 100%

— rats loups 100%

### Attaque (actions sont aléatoire)

— attaquer le héros 0%

— augmenter le niveau de protection 0%
