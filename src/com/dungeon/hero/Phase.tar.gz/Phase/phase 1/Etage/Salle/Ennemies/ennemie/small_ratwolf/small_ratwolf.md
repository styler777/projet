# Small Ratwolf 



**Points de vie :** 32 pts

**Experience xp :** 7xp

**Equipement    :** 

![Alt text](Attack.png "a title")
![Alt text](protection.webp "a title")
