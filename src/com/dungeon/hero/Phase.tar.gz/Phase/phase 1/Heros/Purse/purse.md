# 🦊 Purse — La Packrat (raton des sacs)
🧬 Espèce : Packrat

(littéralement “rat de sac”, en référence à son obsession pour les objets et leur rangement)

**💡 Capacité spéciale / Gimmick :**

Purse se bat à l’aide d’un système d’inventaire classique, mais possède une mécanique unique d’objets bonus — elle peut faire apparaître des objets temporaires à chaque tour.

**⚙️ Détails de sa mécanique spéciale**
🪓 Scratch

Coût : 1 Énergie

Effet : inflige 3 dégâts à un ennemi.

C’est son attaque de base, équivalente à un “coup standard”.

**🎁 Bonus Items**

À chaque tour, Purse a une chance de faire apparaître un objet aléatoire à gauche de son sac à dos.

Cet objet peut être ajouté à ton sac en réorganisant ton inventaire.

Si tu ne le récupères pas avant la fin du tour, il est perdu à jamais.

Tu peux obtenir jusqu’à 3 objets bonus par combat maximum.

**💡 Cette mécanique encourage à :**

réorganiser souvent ton sac en plein combat,

expérimenter avec de nouveaux objets,

et tirer avantage du hasard pour obtenir de bons items temporaires.

**🧩 Objets et synergies uniques**

Purse a accès à des objets spéciaux centrés sur :

Les Cleavers (coupe-choses) : des armes qui s’activent entre elles, créant des chaînes d’attaques puissantes.

Des objets qui renforcent “Scratch” (plus de dégâts, effets additionnels, etc.).

Des objets qui génèrent, modifient ou suppriment les Bonus Items (pour mieux gérer le flot aléatoire)


## ❤️ Autres caractéristiques

| Stat                | Valeur typique                                                      |
| :------------------ | :------------------------------------------------------------------ |
| 💖 PV de départ     | Standard (35 HP)                                                    |
| ⚡ Énergie par tour  | 3                                                                   |
| 🎒 Taille du sac    | Évolue par cases individuelles                                      |
| 🏹 Accès aux objets | Tous les types d’armes, armures, accessoires et consommables du jeu |


## 🧭 Résumé

| Élément               | Détail                                                         |
| :-------------------- | :------------------------------------------------------------- |
| 🐭 Espèce             | Packrat                                                        |
| ⚔️ Attaque de base    | *Scratch* (1 énergie, 3 dégâts)                                |
| 🎁 Mécanique spéciale | *Bonus Items!* – objets aléatoires qui apparaissent en combat  |
| 🪓 Objets uniques     | Cleavers, objets liés à Scratch et à la gestion d’objets bonus |
| 🎒 Style de sac       | Grille classique qui grandit par cases                         |
| 💬 Type de gameplay   | Polyvalent, simple mais stratégique                            |
