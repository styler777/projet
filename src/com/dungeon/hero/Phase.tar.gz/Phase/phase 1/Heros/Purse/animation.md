## 1. Animations de base (toujours nécessaires)

✅ Idle (attente)

Le héros respire ou se balance légèrement.

Animation par défaut quand il ne fait rien.

✅ Walk / Move

Petite animation de déplacement (si tu montres le héros bouger entre salles).

✅ Hurt / Damage Taken

Jouée quand il reçoit des dégâts.

✅ Death

S’effondre ou disparaît.

## 🟩 2. Animations de combat

⚔️ Attack – Basic

🌟 Use Item

Animation courte quand le héros utilise un objet du sac (potion, bouclier, sort).

Exemple : lever la main, effet visuel, particules.

🛡️ Defend / Block

Lever un bouclier ou effet d’énergie autour du héros.

## 🟨 3. Animations liées au sac à dos (spécifiques à Backpack Hero)

🎒 Open Backpack

Le héros ouvre son sac (optionnel si le sac est dans l’UI).

🧩 Rearrange (optionnel)

Animation légère quand le joueur change la disposition du sac.

✨ Looting / Pick Item

Animation pour récupérer un objet dans un coffre ou une récompense.

## Ennemi

protection 

attaquer 