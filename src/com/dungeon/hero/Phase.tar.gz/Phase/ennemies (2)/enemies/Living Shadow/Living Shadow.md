# Living Shadow


**Points de vie :** 140 pts

**Expérience :** 20 xp

**Pouvoir :** 

![Texte alternatif](144px-Living_Shadow.gif "Titre de l'image").

**Equipements :**

![Texte alternatif](40px-Attack.webp "Titre de l'image").,

![Texte alternatif](29px-Power_Shadow_Actor.png "Titre de l'image").
