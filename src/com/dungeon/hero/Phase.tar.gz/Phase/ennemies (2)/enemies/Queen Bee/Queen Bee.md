# Queen Bee



**Points de vie :** 105 pts

**Expérience :** 24 xp

**Equipements :**
- Li'l Bee
![Texte alternatif](35px-Summon.webp "Titre de l'image")

![Texte alternatif](35px-Summon.webp "Titre de l'image")
(Li'l Bee)
![Texte alternatif](35px-Block.webp "Titre de l'image")


![Texte alternatif](60px-Attack.webp "Titre de l'image")

![Texte alternatif](30px-Status_Poison.webp "Titre de l'image")